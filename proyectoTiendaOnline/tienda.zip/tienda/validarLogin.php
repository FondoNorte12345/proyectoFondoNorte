<?php

$user = $_POST['user'];
$pass = $_POST['pass'];

require 'db.php';

$query = "SELECT VALIDAR_USUARIO('$user', '$pass') AS VALIDO";
$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);

if ($row['VALIDO'] == 1) {
    session_start();
    $_SESSION['user'] = $user;

    header('Location: index.php');
}else {
    session_start();
    $error_message = "Usuario o contraseña incorrectos.";
    $_SESSION['mensage_error_login'] = $error_message;
    header('Location: login.php');
}

