<?php
require('db.php');

session_start();
//hecho por victor
$total = isset($_SESSION['carrito_total']) ? $_SESSION['carrito_total'] : 0;


if (!isset($_SESSION['user'])) {
    // Redirigir al usuario si no está autenticado
    header('Location: login.php');
    exit();
}

$query = 'CALL LISTACARRITO("' . $_SESSION['user'] . '");';
$consulta = $con->query($query);
$filas = array();

while ($row = $consulta->fetch_assoc()) {
    $filas[] = $row;
}




?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Carrito</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</head>

<body>
    <header>
        <?php require('navbar.php'); ?>
    </header>
    <h1>Mi Cesta</h1>

    <?php if (empty($filas)) : ?>
        <p>No hay productos en el carrito.</p>
    <?php else : ?>
        <ul>
            <?php foreach ($filas as $producto) : ?>
                <li>
                    <?= $producto['NOM_PRODUCTO'] ?> - Unidades: <?= $producto['CANTPRODUCTO'] ?> - <?= $producto['PRECIO'] ?>€

                </li>
            <?php endforeach; ?>
        </ul>

        <p>Total: <?= $total ?> €</p>
        <button class="btn btn-primary" type="button" onclick="irCheckout()">Comprar productos</button>

    <?php endif; ?>



</body>
<script>
    function irCheckout() {
        window.location.href = 'checkout.php';
    }
</script>

</html>