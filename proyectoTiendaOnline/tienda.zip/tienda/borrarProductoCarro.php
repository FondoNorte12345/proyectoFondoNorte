<?php
session_start();

require('db.php');

if(isset($_POST['cod_producto']) && isset($_SESSION['user'])) {
    $cod_producto = $_POST['cod_producto'];
    $user = $_SESSION['user'];

    $query = 'CALL BORRAR_PRODUCTO_CARRITO(?, ?)';
    
    $stmt = $con->prepare($query);

    $stmt->bind_param('is', $cod_producto, $user);
    $stmt->execute();
   
    $stmt->close();

    header('Location: carrito.php');
    exit();
    
} else {
    echo "Error: Parámetros incorrectos";
}
