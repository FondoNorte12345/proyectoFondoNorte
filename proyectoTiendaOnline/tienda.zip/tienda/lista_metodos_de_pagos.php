<?php

    session_start();
    require_once 'db.php';

    $query = "CALL LISTAR_METODO_PAGOS('$_SESSION[user]');";

    $result = $con->query($query);

        $direcciones = array();
        
        while ($row = $result->fetch_assoc()) {
            $direcciones[] = $row;
        }

        echo json_encode($direcciones);