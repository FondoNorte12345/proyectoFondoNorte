<?php
require 'db.php';

$direcciones = array();

if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

    $query = 'CALL LISTAR_DIRECCIONES("' . $user . '");';

    $consulta = mysqli_multi_query($con, $query);

    if ($consulta) {
        do {
            if ($resultado = mysqli_store_result($con)) {

                while ($fila = mysqli_fetch_assoc($resultado)) {
                    $direcciones[] = $fila;
                }
                mysqli_free_result($resultado);
            }
        } while (mysqli_next_result($con));
        
        // Devolver las direcciones en formato JSON
          json_encode($direcciones);
    } else {
         json_encode($direcciones);
    }
} else {
    echo "El usuario no está autenticado.";
}




