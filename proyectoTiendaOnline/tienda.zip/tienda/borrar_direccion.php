<?php

require_once 'db.php';

session_start();

$cod = $_GET['cod'];

if (isset($_SESSION)) {

    $query = "CALL BORRAR_DIRRECCION_MICUENTA($cod);";
    $resultborrarDireccion = mysqli_query($con, $query);

    if ($resultborrarDireccion) {
        echo "alert('borrado');";
        header('Location: micuenta.php');
    }

} else {
    echo "alert('no hay sesion');";
}

