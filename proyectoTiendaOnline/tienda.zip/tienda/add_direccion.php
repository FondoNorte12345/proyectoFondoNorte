<?php


require_once 'db.php';

session_start();

if (isset($_SESSION)) {
   
    $user = $_SESSION['user'];
    $direccion = $_POST['direccion'];
    $ciudad = $_POST['ciudad'];
    $provincia = $_POST['provincia'];
    $pais = $_POST['pais'];
    $cp = $_POST['cp'];

    echo $user . " " . $direccion . " " . $ciudad . " " . $provincia . " " . $pais . " " . $cp;

    $query = "CALL INSERTAR_DIRECCION('".$user."', '" . $direccion . "', '" . $ciudad . "', '" . $provincia . "', '" . $pais . "', '" . $cp . "');";
 

   $resultAddDireccion = mysqli_query($con, $query);

    if ($resultAddDireccion) {
        header('Location: micuenta.php');
    }
} else {
    echo "no hay sesion";
}



