<?php


require_once 'db.php';

session_start();

if (isset($_SESSION)) {

    $numero = $_POST['numero'];
    $scadenzacarta = $_POST['scadenza_carta'];
    $titolare_carta = $_POST['titolare_carta'];
    $cvv = $_POST['cvv'];
    $user = $_SESSION['user'];

    $query = "CALL ADD_METODO_DE_PAGO_TARJETA('" . $user . "', '" . $numero . "', '" . $scadenzacarta . "', '" . $titolare_carta . "', '" . $cvv . "', 'VISA');";

    $resultAddDireccion = mysqli_query($con, $query);

    if ($resultAddDireccion) {
        header('Location: micuenta.php');
        exit();
    }
}