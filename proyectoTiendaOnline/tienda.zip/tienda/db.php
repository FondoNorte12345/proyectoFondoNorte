<?php
$SERVER = "localhost";
$USER = "root";
$PASS = "";
$DB = "TIENDAONLINE";

$con = mysqli_connect($SERVER, $USER, $PASS, $DB);
if (mysqli_connect_errno())
{
 echo "Connection fallida: " . mysqli_connect_error();
}
