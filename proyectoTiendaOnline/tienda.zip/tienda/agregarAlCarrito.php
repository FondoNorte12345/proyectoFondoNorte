<?php
session_start();

require('db.php');



if(isset($_POST['cod_producto']) && isset($_SESSION['user'])) {
    $query = 'CALL INSERTAR_PRODUCTO_CARRO(?, ?)';
    
    $stmt = $con->prepare($query);

    $stmt->bind_param('is', $_POST['cod_producto'], $_SESSION['user']);
    $stmt->execute();

    $stmt->close();

    header('Location: carrito.php');
    exit();
} else {
    header('Location: login.php');
    exit();
}


