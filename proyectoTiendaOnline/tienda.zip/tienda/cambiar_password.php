<?php

require_once 'db.php';

session_start();

$pass_old = $_POST['passwordAntigua'];
$pass_new = $_POST['passwordNueva'];
$pass_repetida = $_POST['passwordRepetir'];

$validarDatos = true;

$_SESSION['mensage_error_login'] = "";

if ($pass_old == "" || $pass_new == "" || $pass_repetida == "") {
    $error_message = "Todos los campos son obligatorios.";
    $_SESSION['mensage_error_login'] = $error_message;
    header('Location: micuenta.php');
    exit();
}
if ($pass_new != $pass_repetida) {
    $error_message = "Las contraseñas no coinciden.";
    $_SESSION['mensage_error_login'] = $error_message;
    header('Location: micuenta.php');
    exit();
}
if ($pass_old == $pass_new) {
    $error_message = "La nueva contraseña no puede ser igual a la antigua.";
    $_SESSION['mensage_error_login'] = $error_message;
    header('Location: micuenta.php');
    exit();
}

$query = "CALL CAMBIAR_PASSWORD('" . $_SESSION['user'] . "', '" . $pass_new . "', '" . $pass_old . "');";

$result = mysqli_query($con, $query);

if ($result) {
    $error_message = "Contraseña cambiada con exito.";
    $_SESSION['mensage_error_login'] = $error_message;
    header('Location: micuenta.php');
    exit();
} else {
    $error_message = "Error al cambiar la contraseña.";
}










