<?php

require('db.php');

$query = 'CALL LISTAPRODUCTOSPRINCIPAL();';
$consulta = $con->query($query);

$filasproducto = array();

while ($row = $consulta->fetch_assoc()) {
    $filasproducto[] = $row;
}


function obtenerFotosProducto($codigoProducto) {

    require('db.php');

    $query = 'CALL FOTOSPRODUCTO(' . $codigoProducto . ');';
    $consulta = $con->query($query);

    $filasproducto = array();

    while ($row = $consulta->fetch_assoc()) {
        $filasproducto[] = $row;
    }

    echo json_encode($filasproducto);
    return json_encode($filasproducto);
}

?>

<style>


</style>

<div id="modal" class="modal" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span class="cerrar" onclick="cerrarModal()">&times;</span>
                </button>
            </div>
            <!-- arma un carusel -->
            <div class="container d-flex justify-content-center">
                <div id="carouselExampleIndicators" class="carousel slide w-50" data-ride="carousel">
                    <div class="carousel-inner">
                        <div id="carousel_fotos"></div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <div class="card mb-4 box-shadow">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal" id="nombre"></h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title" id="precio"> <small class="text-muted">Є</small></h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li id="marca"></li>
                        <li id="modelo"></li>
                    </ul>
                    <div id="boton-cesta"></div>
                    <p id="descripcion"></p>
                </div>
            </div>
            <div class="modal-body">
                <div class="modal-contenido">
                    <div class="detalles-producto">
                    </div>
                </div>
                <div class="modal-footer">
                </div>
            </div>
        </div>
    </div>
</div>

<div id="listado" class="row "></div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    let divListado = document.getElementById("listado");

    let filasproducto = <?= json_encode($filasproducto) ?>;

    for (let i = 0; i < filasproducto.length; i++) {
        let nombreProducto = filasproducto[i].NOM_PRODUCTO;
        let urlImagen = filasproducto[i].URL_FOTO;
        let precio = filasproducto[i].PRECIO;
        let cod_producto = filasproducto[i].COD_PRODUCTO;
        divListado.innerHTML += `<div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="card shadow-sm">
                                    <img src="${urlImagen}" class="bd-placeholder-img card-img-top" width="100%" 
                                    </img>
                                    <div class="card-body">
                                        <p class="card-text">${nombreProducto}</p>
                                        <p class="card-text">${precio}<span> €</span></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="btn-group">
                                                <button type="button"
                                                     class="btn btn-sm btn-outline-secondary" onClick="verDetalles(${cod_producto})">Ver detalles</button>
                                                   
                                                <button type="button" class="btn btn-sm btn-outline-secondary" onClick="agregarAlCarrito(${cod_producto})">Añadir al
                                                    carrito</button>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                </div>`;
    }
    divListado.innerHTML += `</div>`;

    

    function agregarAlCarrito(i) {
        jQuery.post("agregarAlCarrito.php", { cod_producto: i });
        <?php if(!isset($_SESSION['user'])) {
            echo "alert('Por favor, inicia sesión para poder agregar productos al carrito');";
        }?>
        location.reload();
    }

    let datos = '';

    function cargarDetallesProducto(codigoProducto) {
        let xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                let capura = xhr.responseText;
                datos = JSON.parse(capura);
                armarModal(datos);
            }
        };
        xhr.open('GET', 'detProducto.php?codigo=' + codigoProducto, true);
        xhr.send();
    }

    function cargarFotos(codigoProducto) {
        let xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                let capura = xhr.responseText;
                datos = JSON.parse(capura);
                armarCarusel(datos);
            }
        };
        xhr.open('GET', 'obtenerFotosProductos.php?codigo=' + codigoProducto, true);
        xhr.send();
    }

    


    function verDetalles(codigoProducto) {
        document.getElementById('modal').style.display = 'block';

 
        cargarDetallesProducto(codigoProducto);
    }

    function cerrarModal() {

        document.getElementById('modal').style.display = 'none';
    }

    function armarCarusel(datos) {
        console.log(datos);

        document.getElementById('carousel_fotos').innerHTML = ``;

        datos.forEach((element, index) => {
            if (index == 0){
                document.getElementById('carousel_fotos').innerHTML += `<div class="carousel-item active">
            <img src="${element.URL_FOTO}" class="d-block w-100" alt="...">
            </div>`
            }else{
                console.log("Si hay imagenes");
                document.getElementById('carousel_fotos').innerHTML += `<div class="carousel-item">
            <img src="${element.URL_FOTO}" class="d-block w-100" alt="...">
            </div>`;
            }
        })
    }


    function armarModal(datosProducto) {
        console.log(datosProducto);

            datosProducto = datosProducto[0];

            console.log(JSON.stringify(datosProducto.NOM_PRODUCTO));

            document.getElementById('nombre').innerHTML = datosProducto.NOM_PRODUCTO;
            document.getElementById('descripcion').innerHTML = datosProducto.DESC_PRODUCTO;
            document.getElementById('marca').innerHTML = datosProducto.MARCA;
            document.getElementById('modelo').innerHTML = "Modelo: " +datosProducto.MODELO;
            document.getElementById('precio').innerHTML = datosProducto.PRECIO;
            cargarFotos(datosProducto.COD_PRODUCTO);

            document.getElementById('boton-cesta').innerHTML = `<button type="button" class="btn btn-primary" onClick="agregarAlCarrito(${datosProducto.COD_PRODUCTO})">Añadir al carrito</button>`;
            
    }
</script>