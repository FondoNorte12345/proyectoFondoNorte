<?php
session_start();
$user = $_SESSION['user'];

if (!isset($user)) {
    header('Location: login.php');
}

require('db.php');

$query = 'CALL DATOSUSUARIOS("' . $user . '");';

$consulta = mysqli_query($con, $query);

$datosUsuario = array();

if ($consulta) {
    while ($row = mysqli_fetch_assoc($consulta)) {
        $datosUsuario[] = $row;
    }
}

$datosUsuario = json_encode($datosUsuario);
?>

<?php require('listarDirecciones.php'); ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fondo Norte Componetes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <style>
        body {
            margin: 0;
            background-color: #f8f9fa;
        }

        main {
            height: 200vh;
        }
    </style>
</head>

<body>
    <header>
        <?php require('navbar.php'); ?>
    </header>
    <main>

        <div class="modal fade" id="direccionesModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="direccionesModalLabel">Nueva Direccion</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="add_direccion.php">
                            <div class="mb-3">
                                <label for="calleinput" class="col-form-label">Calle</label>
                                <input type="text" class="form-control" id="calleinput" name="direccion">
                            </div>
                            <div class="mb-3">
                                <label for="Ciudadinput" class="col-form-label">Ciudad</label>
                                <input type="text" class="form-control" id="Ciudadinput" name="ciudad">
                            </div>
                            <div class="mb-3">
                                <label for="Provinciainput" class="col-form-label">Provincia</label>
                                <input type="text" class="form-control" id="Provinciainput" name="provincia">
                            </div>
                            <div class="mb-3">
                                <label for="Provinciainput" class="col-form-label">Pais</label>
                                <input type="text" class="form-control" id="Paisinput" name="pais">
                            </div>
                            <div class="mb-3">
                                <label for="Provinciainput" class="col-form-label">C.P.</label>
                                <input type="text" class="form-control" id="Cpinput" name="cp">
                            </div>
                            <button type="submit" class="btn btn-primary">Añade</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>



        <div class="modal fade" id="metodosdepagoModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="metodosdepagoModalLabel">Nueva Direccion</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="add_metodopago.php">
                            <div class="mb-3">
                                <label for="metodo" class="col-form-label">Método de pago</label>
                                <select class="form-select" id="metodo" name="metodo" onchange="numeroCarta()" required>
                                    <option value="">Selecciona un método</option>
                                    <option value="visa">Visa</option>
                                    <option value="paypal">Paypal</option>
                                </select>
                            </div>
                            <div id="Formulariotarjeta"></div>
                        
                            <button type="submit" class="btn btn-primary">Añadir método de pago</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-2">
            </div>
            <div class="col-8">
                <h2>Mi cuenta</h2>
                <div class="row">
                    <div class="col-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Información de contacto</h5>
                                <p class="card-text" id="email"></p>
                                <p class="card-text" id="nombre"></p>
                                <p class="card-text" id="apellido"></p>
                                <p class="card-text" id="tel"></p>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <h2>Metodo de pago</h2>
                                <div class="card">
                                    <div class="card-body">
                                        <button type="button" class="btn btn" data-bs-toggle="modal"
                                            data-bs-target="#metodosdepagoModal">Añade un metodo de pago
                                            +</button>
                                    </div>
                                </div>
                                <div id="metodosdepago"></div>
                            </div>
                        </div>

                    </div>
                    <div class="col-6">
                        <div class="card d-flex justify-content-center">
                            <?php

                            if (isset($_SESSION['mensage_error_login']) && !empty($_SESSION['mensage_error_login'])) {
                                echo '<div class="alert alert-danger" role="alert">
                            ' . $_SESSION['mensage_error_login'] . '
                          </div>';
                            }
                            $_SESSION['mensage_error_login'] = "";
                            ?>
                            <div class="card-body">
                                <form action="cambiar_password.php" method="POST">
                                    <h5 class="card-title">Información de usuario</h5>
                                    <label for="pass">Antigua contraseña</label>
                                    <input type="password" class="form-control" name="passwordAntigua">
                                    <label for="pass">Nueva contraseña</label>
                                    <input type="password" class="form-control" name="passwordNueva">
                                    <label for="pass">Repite la nueva contraseña</label>
                                    <input type="password" class="form-control" name="passwordRepetir">
                                    <br>
                                    <button type="submit" class="btn btn-primary">Cambiar</button>
                                </form>
                            </div>
                        </div>
                        <br>
                        <div class="card">
                            <div class="card-body">
                                <h2>Mis direcciones</h2>
                                <div class="card">
                                    <div class="card-body">
                                        <button type="button" class="btn btn" data-bs-toggle="modal"
                                            data-bs-target="#direccionesModal">Añade nueva dirección
                                            +</button>
                                    </div>
                                </div>
                                <div id="direcciones"></div>
                            </div>
                        </div>
                        <div class="col-2">
                        </div>
                    </div>
                    <div class="col-7">
                    </div>
                </div>

    </main>
    <?php require('footer.php'); ?>
</body>
<script>

    let user = <?= $datosUsuario ?>;

    let direcciones = <?= json_encode($direcciones) ?>


    function numeroCarta() {
        let tipotarjeta = document.getElementById('metodo').value;
        let input = document.getElementById('Formulariotarjeta');
        switch (tipotarjeta) {
            case 'visa':
                input.innerHTML = `<div class="mb-3">
                                <label for="numeroCarta" class="col-form-label">Número de tarjeta</label>
                                <div id="numeroCarta"></div>
                                <input type="text" class="form-control" id="numero" name="numero" placeholder="XXXX XXXX XXXX XXXX" required patten="^4[0-9]{12}(?:[0-9]{3})?$">
                            </div>
                            <div class="mb-3">
                                <label for="scadenzaCarta" class="col-form-label">Fecha de vencimiento</label>
                                <input type="text" class="form-control" id="scadenzaCarta" name="scadenza_carta"
                                    placeholder="MM/YY" required>
                            </div>
                            <div class="mb-3">
                                <label for="titolareCarta" class="col-form-label">Titular de la tarjeta</label>
                                <input type="text" class="form-control" id="titolareCarta" name="titolare_carta"
                                    required>
                            </div>
                            <div class="mb-3">
                                <label for="cvv" class="col-form-label">CVV</label>
                                <input type="text" class="form-control" id="cvv" name="cvv" required>
                            </div>`;
                break;
            case 'paypal':
                input.innerHTML = `<div class="mb-3">
                                <label for="correo" class="col-form-label">Correo</label>
                                <div id="correo"></div>
                                <input type="email" class="form-control" id="correo" name="correo" required>
                            </div><div class="mb-3">
                                <label for="password" class="col-form-label">Password</label>
                                <div id="password"></div>
                                <input type="password" class="form-control" id="password" name="correo" required>
                            </div>`;
                break;
            }
    }
 



    document.getElementById('email').innerHTML = user[0].CORREO;
    document.getElementById('nombre').innerHTML = user[0].NOMBRE;
    document.getElementById('apellido').innerHTML = user[0].APELLIDO1 + " " + user[0].APELLIDO2;
    document.getElementById('tel').innerHTML = user[0].TELEFONO;


    direcciones.forEach(element => {
        console.log(element);
        document.getElementById('direcciones').innerHTML += `<div class="card">
       <div class="card-body">            
           <h5 class="card-title">Calle : ${element.DIRECCION}</h5>
           <p class="card-text">Ciudad : ${element.CIUDAD}</p>
           <p class="card-text">Provincia : ${element.PROVINCIA}</p>
           <p class="card-text">Pais : ${element.PAIS}</p>
           <p class="card-text">C.P. : ${element.CP}</p>
        <div class="card-body"><a href="borrar_direccion.php?cod=${element.COD_DIRECCION}" class="btn btn">Borrar <i class="bi bi-trash3"></i></a></div>
       </div>
   </div><br>`;
    });


    let direccionesModal = document.getElementById('direccionesModal');

    direccionesModal.addEventListener('show.bs.modal', event => {
    });

    let metodosdepago = document.getElementById('metodosdepagoModal');

    metodosdepago.addEventListener('show.bs.modal', event => {
    });

</script>

</html>